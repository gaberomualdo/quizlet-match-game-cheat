var updated = false;
var colors = [
	"#e74c3c",
	"#2133ff",
	"#2ecc71",
	"#f1c40f",
	"black",
	"white"
];
var colorz = [
	"white",
	"white",
	"white",
	"black",
	"white",
	"black"
];
if(document.domain == "quizlet.com" && document.URL.indexOf("match") != -1){
	setInterval(function(){
		if(!updated){
			var tiles = document.querySelectorAll(".MatchModeQuestionScatterTile");
			if(tiles.length > 0){
				updated = true;
				for(var index = 0;index < tiles.length;index+=1){
					tiles[index].style.backgroundColor = colors[Math.floor(index / 2)];
					tiles[index].style.borderColor = colors[Math.floor(index / 2)];
					tiles[index].style.color = colorz[Math.floor(index / 2)];
					tiles[index].setAttribute("id",index);
				}
			}
		}
	},250);
}